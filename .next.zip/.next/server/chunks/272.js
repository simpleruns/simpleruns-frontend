"use strict";
exports.id = 272;
exports.ids = [272];
exports.modules = {

/***/ 5685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6358);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dropzone__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__);




const Dropzone = ({ onDrop , selectedFiles , id , setLicencePhotoHandler  })=>{
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectedFiles || []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLicencePhotoHandler(files);
    }, [
        files
    ]);
    const validator = (file)=>{
        const maxSize = 1024 * 1024 * 5; // 5 MB
        const allowedTypes = [
            "image/jpeg",
            "image/png",
            "image/svg",
            "image/gif"
        ];
        if (file.size > maxSize) {
            alert(`File ${file.name} is too large. Maximum size is 5 MB.`);
            return false;
        }
        if (!allowedTypes.includes(file.type)) {
            alert(`File ${file.name} is not a valid image file. Allowed types are JPEG and PNG.`);
            return false;
        }
        return true;
    };
    const { getRootProps , getInputProps , isDragActive  } = (0,react_dropzone__WEBPACK_IMPORTED_MODULE_2__.useDropzone)({
        accept: "image/*",
        onDrop: (acceptedFiles)=>{
            const validFiles = acceptedFiles.filter(validator);
            setFiles((prevFiles)=>[
                    ...prevFiles,
                    ...validFiles
                ]);
            onDrop(validFiles);
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ...getRootProps(),
        id: id,
        className: `${isDragActive ? "bg-gray-100 dark:bg-navy-900" : "bg-gray-50 hover:bg-gray-100 dark:bg-navy-800"} px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md !bg-transparent transition`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                ...getInputProps(),
                name: "drop-zone",
                id: id
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__.SlPlus, {
                        className: "mx-auto h-12 w-12 text-gray-400"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mt-1 text-sm text-gray-600",
                        children: "Drag and drop some files here, or click to select files"
                    })
                ]
            }),
            files.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-lg font-medium leading-6 text-gray-900 dark:text-white",
                        children: "Selected files"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "mt-2 border-t border-b border-gray-200 divide-y divide-gray-200",
                        children: files.map((file)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                id: file.name,
                                className: "py-3 flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm font-medium text-gray-900 dark:text-white",
                                        children: file.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "ml-4 bg-red-500 text-white px-2 py-1 rounded-md",
                                        onClick: ()=>setFiles((prevFiles)=>prevFiles.filter((prevFile)=>prevFile !== file)),
                                        children: "Remove"
                                    })
                                ]
                            }, file.name))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dropzone);


/***/ }),

/***/ 4859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6358);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dropzone__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__);




const DropzoneForFile = ({ onDrop , selectedFiles , id , setLicencePhotoHandler  })=>{
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectedFiles || []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLicencePhotoHandler(files);
    }, [
        files
    ]);
    const validator = (file)=>{
        const maxSize = 1024 * 1024 * 5; // 5 MB
        // const allowedTypes = ['image/jpeg', 'image/png', 'image/svg', 'image/gif'];
        if (file.size > maxSize) {
            alert(`File ${file.name} is too large. Maximum size is 5 MB.`);
            return false;
        }
        // if (!allowedTypes.includes(file.type)) {
        //     alert(`File ${file.name} is not a valid image file. Allowed types are JPEG and PNG.`);
        //     return false;
        // }
        return true;
    };
    const { getRootProps , getInputProps , isDragActive  } = (0,react_dropzone__WEBPACK_IMPORTED_MODULE_2__.useDropzone)({
        accept: "image/*",
        onDrop: (acceptedFiles)=>{
            const validFiles = acceptedFiles.filter(validator);
            setFiles((prevFiles)=>[
                    ...prevFiles,
                    ...validFiles
                ]);
            onDrop(validFiles);
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ...getRootProps(),
        id: id,
        className: `${isDragActive ? "bg-gray-100 dark:bg-navy-900" : "bg-gray-50 hover:bg-gray-100 dark:bg-navy-800"} px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md !bg-transparent transition`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                ...getInputProps(),
                name: "drop-zone",
                id: id
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__.SlPlus, {
                        className: "mx-auto h-12 w-12 text-gray-400"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mt-1 text-sm text-gray-600",
                        children: "Drag and drop some files here, or click to select files"
                    })
                ]
            }),
            files.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-lg font-medium leading-6 text-gray-900 dark:text-white",
                        children: "Selected files"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "mt-2 border-t border-b border-gray-200 divide-y divide-gray-200",
                        children: files.map((file)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                id: file.name,
                                className: "py-3 flex justify-between items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm font-medium text-gray-900 dark:text-white",
                                        children: file.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "ml-4 bg-red-500 text-white px-2 py-1 rounded-md",
                                        onClick: ()=>setFiles((prevFiles)=>prevFiles.filter((prevFile)=>prevFile !== file)),
                                        children: "Remove"
                                    })
                                ]
                            }, file.name))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DropzoneForFile);


/***/ }),

/***/ 8442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ instance)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    // baseURL: 'https://simpleruns-backend.vercel.app/api',
    baseURL: "http://170.64.154.214/api",
    // baseURL: 'http://localhost:4000/api',
    timeout: 50000,
    headers: {
        "Access-Control-Allow-Origin": "*"
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;